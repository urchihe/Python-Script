<?php

namespace App\Http\Controllers\Traits;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DealsWithAdminNotifications extends Controller
{
    //
}
