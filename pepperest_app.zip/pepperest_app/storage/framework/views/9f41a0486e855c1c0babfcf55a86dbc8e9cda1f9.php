<?php $__env->startComponent('mail::message'); ?>
# Contact Request

#### From: <?php echo e($request->name); ?> <<?php echo e($request->email); ?>>

<?php echo e($request->message); ?>


Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
