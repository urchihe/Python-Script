<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paystack_banks extends Model
{
    //
}
