<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Flutterwave_countries extends Model
{
    //
}
