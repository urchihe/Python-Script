<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment_logs extends Model
{
    //
}
