<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Loginfos extends Model
{
    //
}
