<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\Responds;
use Validator;

class PaymentController extends Controller
{
	use Responds;

  

   
}
