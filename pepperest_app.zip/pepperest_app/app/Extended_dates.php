<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Extended_dates extends Model
{
    //
}
