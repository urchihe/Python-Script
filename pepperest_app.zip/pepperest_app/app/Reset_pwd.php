<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reset_pwd extends Model
{
    //
}
