<?php

namespace App\Http\Controllers\Traits;

trait Transactions
{
  
}

