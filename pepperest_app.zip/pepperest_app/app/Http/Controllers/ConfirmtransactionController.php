<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ConfirmtransactionController extends Controller
{
    //
}
