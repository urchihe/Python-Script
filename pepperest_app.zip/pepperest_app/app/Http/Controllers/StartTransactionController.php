<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StartTransactionController extends Controller
{
    //
}
