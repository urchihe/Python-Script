<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPromoCode extends Model
{
    //
    protected $table = "user_has_promoCode";
    public $timestamps = false;
    protected $guarded = [];
}
