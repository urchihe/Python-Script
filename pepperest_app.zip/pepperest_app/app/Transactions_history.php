<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transactions_history extends Model
{
    //
}
